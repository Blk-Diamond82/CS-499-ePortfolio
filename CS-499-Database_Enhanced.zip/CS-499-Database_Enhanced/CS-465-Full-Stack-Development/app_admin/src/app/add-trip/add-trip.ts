import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';

@Component({
  selector: 'app-add-trip',
  imports: [CommonModule, FormsModule],
  templateUrl: './add-trip.html',
  styleUrl: './add-trip.css',
})
export class AddTrip {
  public message = '';

  public trip: Trip = {
    _id: '',
    code: 'REEF01',
    name: 'Coral Reef Escape',
    length: '6 nights',
    start: '2026-08-15',
    resort: 'Blue Lagoon Dive Resort',
    perPerson: '749',
    image: 'reef1.jpg',
    description:
      'Explore vibrant coral reefs and enjoy guided underwater adventures.',
  };

constructor(private readonly tripDataService: TripData,private readonly router: Router,) {}

 public submitTrip(): void {
  this.message = '';

  this.tripDataService.addTrip(this.trip).subscribe({
    next: () => {
      this.router.navigate(['/']);
    },
    error: (error) => {
      console.error('Unable to add trip:', error);
      this.message = 'Unable to add trip.';
    },
  });
}
}