import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';

@Component({
  selector: 'app-edit-trip',
  imports: [CommonModule, FormsModule],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css',
})
export class EditTrip implements OnInit {
  public readonly trip = signal<Trip | null>(null);
  public readonly message = signal('Loading trip...');

  constructor(
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly tripDataService: TripData
  ) {}

  public ngOnInit(): void {
    const code = this.route.snapshot.paramMap.get('tripCode');

    if (!code) {
      this.message.set('No trip code was provided.');
      return;
    }

    this.tripDataService.getTrip(code).subscribe({
      next: (trip) => {
        this.trip.set(trip);
        this.message.set('');
      },
      error: (error) => {
        console.error('Unable to load selected trip:', error);
        this.message.set('Unable to load the selected trip.');
      },
    });
  }

  public updateTrip(): void {
    const selectedTrip = this.trip();

    if (!selectedTrip) {
      return;
    }

    this.tripDataService.updateTrip(selectedTrip).subscribe({
      next: () => {
        this.router.navigate(['/']);
      },
      error: (error) => {
        console.error('Unable to update trip:', error);
        this.message.set('Unable to update the selected trip.');
      },
    });
  }

  public cancel(): void {
    this.router.navigate(['/']);
  }
}