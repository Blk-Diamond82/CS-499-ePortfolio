import { CommonModule } from '@angular/common';
import { Component, computed, OnInit, signal } from '@angular/core';
import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';
import { TripCard } from '../trip-card/trip-card';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-trip-list',
  imports: [CommonModule, TripCard, RouterLink],
  templateUrl: './trip-list.html',
  styleUrl: './trip-list.css',
})
export class TripList implements OnInit {
  public readonly trips = signal<Trip[]>([]);
  public readonly message = signal('');
  public readonly searchTerm = signal('');
  public readonly sortOption = signal<'name' | 'start' | 'price-low' | 'price-high'>('name');
  
  public readonly filteredTrips = computed<Trip[]>(() => {
  const search = this.searchTerm().trim().toLowerCase();

  const matchingTrips = this.trips().filter((trip) => {
    if (!search) {
      return true;
    }

    return (
      trip.name.toLowerCase().includes(search) ||
      trip.code.toLowerCase().includes(search) ||
      trip.resort.toLowerCase().includes(search)
    );
  });

  return [...matchingTrips].sort((a, b) => {
    switch (this.sortOption()) {
      case 'start':
        return new Date(a.start).getTime() - new Date(b.start).getTime();

      case 'price-low':
        return Number(a.perPerson) - Number(b.perPerson);

      case 'price-high':
        return Number(b.perPerson) - Number(a.perPerson);

      case 'name':
      default:
        return a.name.localeCompare(b.name);
    }
  });
});

  constructor(private readonly tripDataService: TripData) {}

  public ngOnInit(): void {
    this.tripDataService.getTrips().subscribe({
      next: (trips) => {
        console.log('Trips returned from API:', trips);
        this.trips.set(trips);
      },
      error: (error) => {
        console.error('Unable to retrieve trips:', error);
        this.message.set('Unable to retrieve trips from the server.');
      },
    });
  }
}
