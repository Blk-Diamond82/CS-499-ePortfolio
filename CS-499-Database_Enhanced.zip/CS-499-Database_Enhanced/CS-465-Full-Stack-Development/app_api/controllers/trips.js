const mongoose = require('mongoose');
const Trip = mongoose.model('Trip');

const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({}).lean();
    return res.status(200).json(trips);
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      message: 'Unable to retrieve trips.'
    });
  }
};

const tripsFindByCode = async (req, res) => {
  try {
    const trip = await Trip.findOne({
      code: req.params.tripCode
    }).lean();

    if (!trip) {
      return res.status(404).json({
        message: 'Trip not found.'
      });
    }

    return res.status(200).json(trip);
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      message: 'Unable to retrieve the requested trip.'
    });
  }
};

const tripsAddTrip = async (req, res) => {
  try {
    const existingTrip = await Trip.findOne({
      code: req.body.code
    }).lean();

    if (existingTrip) {
      return res.status(409).json({
        message: 'A trip with that code already exists.'
      });
    }

    const newTrip = await Trip.create({
      code: req.body.code,
      name: req.body.name,
      length: req.body.length,
      start: req.body.start,
      resort: req.body.resort,
      perPerson: req.body.perPerson,
      image: req.body.image,
      description: req.body.description
    });

    return res.status(201).json(newTrip);
  } catch (err) {
    console.error(err);

    if (err.name === 'ValidationError') {
      return res.status(400).json({
        message: 'Trip data is incomplete or invalid.'
      });
    }

    return res.status(500).json({
      message: 'Unable to add trip.'
    });
  }
};

const tripsUpdateTrip = async (req, res) => {
  try {
    const trip = await Trip.findOne({
      code: req.params.tripCode
    });

    if (!trip) {
      return res.status(404).json({
        message: 'Trip not found.'
      });
    }

    trip.code = req.body.code;
    trip.name = req.body.name;
    trip.length = req.body.length;
    trip.start = req.body.start;
    trip.resort = req.body.resort;
    trip.perPerson = req.body.perPerson;
    trip.image = req.body.image;
    trip.description = req.body.description;

    const updatedTrip = await trip.save();

    return res.status(200).json(updatedTrip);
  } catch (err) {
    console.error(err);

    if (err.name === 'ValidationError') {
      return res.status(400).json({
        message: 'Trip data is incomplete or invalid.'
      });
    }

    return res.status(500).json({
      message: 'Unable to update trip.'
    });
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip
};