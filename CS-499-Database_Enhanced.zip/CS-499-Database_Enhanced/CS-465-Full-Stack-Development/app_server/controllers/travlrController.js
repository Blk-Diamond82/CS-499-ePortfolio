const mongoose = require('mongoose');
const Trip = mongoose.model('Trip');

const home = (req, res) => {
    res.render('index', {
        title: 'Travlr Getaways'
    });
};

const travel = async (req, res, next) => {
    try {
        const trips = await Trip.find({}).lean();

        res.render('travel', {
            title: 'Travel',
            trips
        });
    } catch (err) {
        next(err);
    }
};

module.exports = {
    home,
    travel
};